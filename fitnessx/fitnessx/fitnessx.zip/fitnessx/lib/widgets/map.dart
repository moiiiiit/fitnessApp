import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';

class Map extends StatefulWidget {
  @override
  _MapState createState() => _MapState();
}

class _MapState extends State<Map>{
  PermissionStatus _status;
  
  @override
  void initState(){
    super.initState();
    PermissionHandler().checkPermissionStatus(PermissionGroup.locationWhenInUse)
    .then(_updateStatus);
  }

  void _updateStatus(PermissionStatus status){
    if(status != _status){
      setState(() {
        _status = status;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    GoogleMapController mapController;
    final LatLng _center = const LatLng(37.422, -122.084);

    void _onMapCreated(GoogleMapController controller) {
      mapController = controller;
    }
    // TODO: implement build
    return (
        GoogleMap(
            myLocationEnabled: true,
          onMapCreated: _onMapCreated,
          initialCameraPosition: CameraPosition(
            target: _center,
            zoom: 11.0,
          )));
    }
}